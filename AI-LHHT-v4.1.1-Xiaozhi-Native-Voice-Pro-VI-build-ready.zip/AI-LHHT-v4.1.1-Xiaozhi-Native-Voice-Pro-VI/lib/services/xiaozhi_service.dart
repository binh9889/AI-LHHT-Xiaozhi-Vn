import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_sound/flutter_sound.dart';
import '../services/xiaozhi_websocket_manager.dart';
import '../utils/device_util.dart';
import '../utils/audio_util.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

/// Dịch vụ Xiaozhi事件类型
enum XiaozhiServiceEventType {
  connected,
  disconnected,
  textMessage,
  audioData,
  error,
  voiceCallStart,
  voiceCallEnd,
  userMessage,
}

/// Dịch vụ Xiaozhi事件
class XiaozhiServiceEvent {
  final XiaozhiServiceEventType type;
  final dynamic data;

  XiaozhiServiceEvent(this.type, this.data);
}

/// Dịch vụ Xiaozhi监听器
typedef XiaozhiServiceListener = void Function(XiaozhiServiceEvent event);

/// Tin nhắn监听器
typedef MessageListener = void Function(dynamic message);
typedef RealtimeMcpHandler = Future<String> Function(String query);

/// Dịch vụ Xiaozhi
class XiaozhiService {
  static const String TAG = "XiaozhiService";
  static const String DEFAULT_SERVER = "wss://ws.xiaozhi.ai";

  final String websocketUrl;
  final String macAddress;
  final String clientId;
  final String token;
  String? _sessionId; // Cuộc trò chuyệnID将由服务器提供

  XiaozhiWebSocketManager? _webSocketManager;
  bool _isConnected = false;
  bool _isMuted = false;
  final List<XiaozhiServiceListener> _listeners = [];
  StreamSubscription? _audioStreamSubscription;
  bool _isVoiceCallActive = false;
  WebSocketChannel? _ws;
  bool _hasStartedCall = false;
  MessageListener? _messageListener;
  bool _suppressIncomingAudio = false;
  Completer<void>? _suppressedTtsStopCompleter;
  RealtimeMcpHandler? _realtimeMcpHandler;
  bool _mcpBackendDetected = false;

  // v4.1 response gate: trong lúc chờ STT để Tool Router quyết định, không
  // phát ngay câu trả lời/TTS của Agent. Nếu câu là local tool thì buffer bị
  // bỏ; nếu là hội thoại thường thì mới release. Điều này loại bỏ race khiến
  // các chuỗi kiểu `% gold_price...` hoặc `% search_knowledge...` lọt ra UI.
  bool _responseGateActive = false;
  final List<Uint8List> _gatedAudioFrames = <Uint8List>[];
  final List<String> _gatedTtsSentences = <String>[];
  Timer? _responseGateTimer;

  /// Tạo một service riêng cho mỗi cấu hình/cuộc trò chuyện.
  /// Tránh giữ singleton cũ làm app tiếp tục dùng token hoặc Agent trước đó.
  XiaozhiService({
    required this.websocketUrl,
    required this.macAddress,
    required this.clientId,
    required this.token,
    String? sessionId,
  }) {
    _sessionId = sessionId;
    _init();
  }

  /// 切换到Giọng nói通话Chế độ
  Future<void> switchToVoiceCallMode() async {
    // 如果已经在Giọng nói通话Chế độ，直接返回
    if (_isVoiceCallActive) return;

    try {
      print('$TAG: 正在切换到Giọng nói通话Chế độ');

      // 简化初始化流程，确保干净状态
      await AudioUtil.stopPlaying();
      await AudioUtil.initRecorder();
      await AudioUtil.initPlayer();

      _isVoiceCallActive = true;
      print('$TAG: 已切换到Giọng nói通话Chế độ');
    } catch (e) {
      print('$TAG: 切换到Giọng nói通话Chế độThất bại: $e');
      rethrow;
    }
  }

  /// 切换到普通聊天Chế độ
  Future<void> switchToChatMode() async {
    // 如果已经在普通聊天Chế độ，直接返回
    if (!_isVoiceCallActive) return;

    try {
      print('$TAG: 正在切换到普通聊天Chế độ');

      // 停止Giọng nói通话相关的活动
      await stopListeningCall();

      // 确保播放器停止
      await AudioUtil.stopPlaying();

      _isVoiceCallActive = false;
      print('$TAG: 已切换到普通聊天Chế độ');
    } catch (e) {
      print('$TAG: 切换到普通聊天Chế độThất bại: $e');
      _isVoiceCallActive = false;
    }
  }

  /// 初始化
  Future<void> _init() async {
    // 使用cấu hình中的Địa chỉ MAC作为设备ID
    print('$TAG: 初始化Hoàn tất，使用Địa chỉ MAC作为设备ID: $macAddress');

    // 初始化WebSocket管理器，启用 token
    _webSocketManager = XiaozhiWebSocketManager(
      deviceId: macAddress,
      clientId: clientId,
      enableToken: true,
    );

    // ThêmWebSocket事件监听
    _webSocketManager!.addListener(_onWebSocketEvent);

    // 初始化音频工具
    await AudioUtil.initRecorder();
    await AudioUtil.initPlayer();
  }

  /// Cài đặtTin nhắn监听器
  void setMessageListener(MessageListener listener) {
    _messageListener = listener;
  }

  /// Đăng ký một tool MCP tổng quát để backend Xiaozhi có thể gọi các công cụ
  /// realtime của app. Khi backend gọi tool, kết quả được trả lại cho LLM và
  /// chính Xiaozhi sẽ tổng hợp + phát bằng giọng Agent đã cấu hình trên web.
  void setRealtimeMcpHandler(RealtimeMcpHandler handler) {
    _realtimeMcpHandler = handler;
  }

  bool get isMcpBackendDetected => _mcpBackendDetected;

  /// Thêm事件监听器
  void addListener(XiaozhiServiceListener listener) {
    if (!_listeners.contains(listener)) {
      _listeners.add(listener);
    }
  }

  /// 移除事件监听器
  void removeListener(XiaozhiServiceListener listener) {
    _listeners.remove(listener);
  }

  /// 分发事件到所有监听器
  void _dispatchEvent(XiaozhiServiceEvent event) {
    for (var listener in _listeners) {
      listener(event);
    }
  }

  /// 连接到Dịch vụ Xiaozhi
  Future<void> connect() async {
    if (_isConnected) return;

    try {
      print('$TAG: 开始连接服务器...');

      // 创建WebSocket管理器
      _webSocketManager = XiaozhiWebSocketManager(
        deviceId: macAddress,
        clientId: clientId,
        enableToken: true,
      );

      // ThêmWebSocket事件监听
      _webSocketManager!.addListener(_onWebSocketEvent);

      // 连接WebSocket
      await _webSocketManager!.connect(websocketUrl, token);
    } catch (e) {
      print('$TAG: 连接Thất bại: $e');
      _dispatchEvent(
        XiaozhiServiceEvent(XiaozhiServiceEventType.error, 'Kết nối dịch vụ Xiaozhi thất bại: $e'),
      );
    }
  }

  /// 断开Dịch vụ Xiaozhi连接
  Future<void> disconnect() async {
    discardResponseGate();
    if (!_isConnected || _webSocketManager == null) return;

    try {
      // Hủy音频流订阅
      await _audioStreamSubscription?.cancel();
      _audioStreamSubscription = null;

      // 停止音频录制
      if (AudioUtil.isRecording) {
        await AudioUtil.stopRecording();
      }

      // 断开WebSocket连接
      await _webSocketManager!.disconnect();
      _webSocketManager = null;
      _isConnected = false;
    } catch (e) {
      print('$TAG: 断开连接Thất bại: $e');
    }
  }

  /// Xiaozhi official WebSocket của app này là voice/audio protocol.
  /// Không dùng `listen/detect` như general text chat vì server có thể không
  /// trả response và bản cũ sẽ chờ 15 giây rồi báo timeout.
  Future<String> sendTextMessageSilently(String message) async {
    return sendTextMessage(message);
  }

  Future<String> sendTextMessage(String message) async {
    throw UnsupportedError(
      'Xiaozhi voice protocol không hỗ trợ general text chat trong client này. '
      'Hãy dùng luồng mic/audio hoặc MiniMax/Dify cho tin nhắn gõ.',
    );
  }

  /// 连接Giọng nói通话
  Future<void> connectVoiceCall() async {
    try {
      // 简化流程，确保权限和音频准备就绪
      if (Platform.isIOS || Platform.isAndroid) {
        final status = await Permission.microphone.request();
        if (status != PermissionStatus.granted) {
          print('$TAG: Quyền micrô bị từ chối');
          _dispatchEvent(
            XiaozhiServiceEvent(XiaozhiServiceEventType.error, 'Quyền micrô bị từ chối'),
          );
          return;
        }
      }

      // 初始化音频系统
      await AudioUtil.stopPlaying();
      await AudioUtil.initRecorder();
      await AudioUtil.initPlayer();

      print('$TAG: 正在连接 $websocketUrl');
      print('$TAG: 设备ID: $macAddress');
      print('$TAG: Token启用: true');
      print('$TAG: Token: [đã ẩn]');

      // 使用 WebSocketManager 连接
      _webSocketManager = XiaozhiWebSocketManager(
        deviceId: macAddress,
        clientId: clientId,
        enableToken: true,
      );
      _webSocketManager!.addListener(_onWebSocketEvent);
      await _webSocketManager!.connect(websocketUrl, token);
    } catch (e) {
      print('$TAG: 连接Thất bại: $e');
      rethrow;
    }
  }

  /// 结束Giọng nói通话
  Future<void> disconnectVoiceCall() async {
    if (_webSocketManager == null) return;

    try {
      // 停止音频录制
      if (AudioUtil.isRecording) {
        await AudioUtil.stopRecording();
      }

      // 停止音频播放
      await AudioUtil.stopPlaying();

      // Hủy音频流订阅
      await _audioStreamSubscription?.cancel();
      _audioStreamSubscription = null;

      // 直接断开连接
      await disconnect();
    } catch (e) {
      // 忽略断开连接时的Lỗi
      print('$TAG: 结束Giọng nói通话时发生Lỗi: $e');
    }
  }

  /// 开始说话
  Future<void> startSpeaking() async {
    try {
      final message = {'type': 'speak', 'state': 'start', 'mode': 'auto'};
      _webSocketManager?.sendMessage(jsonEncode(message));
      print('$TAG: 已发送开始说话Tin nhắn');
    } catch (e) {
      print('$TAG: 开始说话Thất bại: $e');
    }
  }

  /// 停止说话
  Future<void> stopSpeaking() async {
    try {
      final message = {'type': 'speak', 'state': 'stop', 'mode': 'auto'};
      _webSocketManager?.sendMessage(jsonEncode(message));
      print('$TAG: 已发送停止说话Tin nhắn');
    } catch (e) {
      print('$TAG: 停止说话Thất bại: $e');
    }
  }

  /// 发送listenTin nhắn
  void _sendListenMessage() async {
    try {
      final listenMessage = {
        'type': 'listen',
        'session_id': _sessionId,
        'state': 'start',
        'mode': 'auto',
      };
      _webSocketManager?.sendMessage(jsonEncode(listenMessage));
      print('$TAG: 已发送listenTin nhắn');

      // 开始录音
      _isVoiceCallActive = true;
      await AudioUtil.startRecording();
    } catch (e) {
      print('$TAG: 发送listenTin nhắnThất bại: $e');
      _dispatchEvent(
        XiaozhiServiceEvent(XiaozhiServiceEventType.error, 'Không thể gửi lệnh nghe: $e'),
      );
    }
  }

  /// 开始听说（Giọng nói通话Chế độ）
  Future<void> startListeningCall() async {
    try {
      // 确保已经有Cuộc trò chuyệnID
      if (_sessionId == null) {
        print('$TAG: 没有Cuộc trò chuyệnID，无法开始监听，等待Cuộc trò chuyệnID初始化...');
        // 等待短暂时间，然后重新检查Cuộc trò chuyệnID
        await Future.delayed(const Duration(milliseconds: 500));
        if (_sessionId == null) {
          print('$TAG: Cuộc trò chuyệnID仍然为空，放弃开始监听');
          throw Exception('Phiên thoại chưa sẵn sàng để ghi âm');
        }
      }

      print('$TAG: 使用Cuộc trò chuyệnID开始录音: $_sessionId');

      // 请求麦克风权限
      if (Platform.isIOS) {
        final micStatus = await Permission.microphone.status;
        if (micStatus != PermissionStatus.granted) {
          final result = await Permission.microphone.request();
          if (result != PermissionStatus.granted) {
            print('$TAG: Quyền micrô bị từ chối');
            _dispatchEvent(
              XiaozhiServiceEvent(XiaozhiServiceEventType.error, 'Quyền micrô bị từ chối'),
            );
            return;
          }
        }

        // 确保音频Cuộc trò chuyện已初始化
        await AudioUtil.initRecorder();
      } else {
        // Android权限请求
        final status = await Permission.microphone.request();
        if (status.isDenied) {
          print('$TAG: Quyền micrô bị từ chối');
          _dispatchEvent(
            XiaozhiServiceEvent(XiaozhiServiceEventType.error, 'Quyền micrô bị từ chối'),
          );
          return;
        }
      }

      // 开始录音
      await AudioUtil.startRecording();

      // Cài đặt音频流订阅
      _audioStreamSubscription = AudioUtil.audioStream.listen((opusData) {
        // 发送音频数据
        _webSocketManager?.sendBinaryMessage(opusData);
      });

      // 发送开始监听命令
      final message = {
        'session_id': _sessionId,
        'type': 'listen',
        'state': 'start',
        'mode': 'auto',
      };
      _webSocketManager?.sendMessage(jsonEncode(message));
      print('$TAG: 已发送开始监听Tin nhắn (Giọng nói通话Chế độ)');
    } catch (e) {
      print('$TAG: 开始监听Thất bại: $e');
      throw Exception('Không thể bắt đầu nhập giọng nói: $e');
    }
  }

  /// 停止听说（Giọng nói通话Chế độ）
  Future<void> stopListeningCall() async {
    try {
      // Hủy音频流订阅
      await _audioStreamSubscription?.cancel();
      _audioStreamSubscription = null;

      // 停止录音
      await AudioUtil.stopRecording();

      // 发送停止监听命令
      if (_sessionId != null && _webSocketManager != null) {
        final message = {
          'session_id': _sessionId,
          'type': 'listen',
          'state': 'stop',
          'mode': 'auto',
        };
        _webSocketManager?.sendMessage(jsonEncode(message));
        print('$TAG: 已发送停止监听Tin nhắn (Giọng nói通话Chế độ)');
      }
    } catch (e) {
      print('$TAG: 停止监听Thất bại: $e');
    }
  }

  /// Hủy发送（上滑Hủy）
  Future<void> abortListening() async {
    try {
      // Hủy音频流订阅
      await _audioStreamSubscription?.cancel();
      _audioStreamSubscription = null;

      // 停止录音
      await AudioUtil.stopRecording();

      // 发送中止命令
      if (_sessionId != null && _webSocketManager != null) {
        final message = {'session_id': _sessionId, 'type': 'abort'};
        _webSocketManager?.sendMessage(jsonEncode(message));
        print('$TAG: 已发送中止Tin nhắn');
      }
    } catch (e) {
      print('$TAG: 中止监听Thất bại: $e');
    }
  }

  /// 切换静音状态
  void toggleMute() {
    _isMuted = !_isMuted;

    if (_webSocketManager == null || !_webSocketManager!.isConnected) return;

    try {
      final request = {'type': _isMuted ? 'voice_mute' : 'voice_unmute'};

      _webSocketManager!.sendMessage(jsonEncode(request));
    } catch (e) {
      print('$TAG: 切换静音状态Thất bại: $e');
    }
  }

  /// 处理WebSocket事件
  void _onWebSocketEvent(XiaozhiEvent event) {
    switch (event.type) {
      case XiaozhiEventType.connected:
        _isConnected = true;
        _dispatchEvent(
          XiaozhiServiceEvent(XiaozhiServiceEventType.connected, null),
        );
        break;

      case XiaozhiEventType.disconnected:
        _isConnected = false;
        discardResponseGate();
        _dispatchEvent(
          XiaozhiServiceEvent(XiaozhiServiceEventType.disconnected, null),
        );
        break;

      case XiaozhiEventType.message:
        _handleTextMessage(event.data as String);
        break;

      case XiaozhiEventType.binaryMessage:
        final audioData = Uint8List.fromList(event.data as List<int>);
        if (_responseGateActive) {
          // Giới hạn buffer để không tăng RAM vô hạn nếu server lỗi protocol.
          if (_gatedAudioFrames.length < 320) {
            _gatedAudioFrames.add(audioData);
          }
        } else if (!_suppressIncomingAudio) {
          AudioUtil.playOpusData(audioData);
        }
        break;

      case XiaozhiEventType.error:
        _dispatchEvent(
          XiaozhiServiceEvent(XiaozhiServiceEventType.error, event.data),
        );
        break;
    }
  }

  /// 处理WebSocketTin nhắn
  void _handleWebSocketMessage(dynamic message) {
    try {
      if (message is String) {
        _handleTextMessage(message);
      } else if (message is List<int>) {
        final audioData = Uint8List.fromList(message);
        if (_responseGateActive) {
          if (_gatedAudioFrames.length < 320) _gatedAudioFrames.add(audioData);
        } else if (!_suppressIncomingAudio) {
          AudioUtil.playOpusData(audioData);
        }
      }
    } catch (e) {
      print('$TAG: 处理Tin nhắnThất bại: $e');
    }
  }

  /// 处理Văn bảnTin nhắn
  void _handleTextMessage(String message) {
    print('$TAG: 收到Văn bảnTin nhắn: $message');
    try {
      final Map<String, dynamic> jsonData = json.decode(message);
      final String type = jsonData['type'] ?? '';

      // 确保首先调用Tin nhắn监听器
      if (_messageListener != null) {
        _messageListener!(jsonData);
      }

      // 更新Cuộc trò chuyệnID（服务器在helloTin nhắn中会提供新的Cuộc trò chuyệnID）
      if (jsonData['session_id'] != null) {
        _sessionId = jsonData['session_id'];
        print('$TAG: 更新Cuộc trò chuyệnID: $_sessionId');
      }

      // 根据Tin nhắn类型分发事件
      switch (type) {
        case 'hello':
          // 处理服务器的hello响应
          if (_isVoiceCallActive && !_hasStartedCall) {
            _hasStartedCall = true;
            // 发送自动说话Chế độTin nhắn
            startSpeaking();
          }
          break;

        case 'start':
          // 收到start响应后，如果是Giọng nói通话Chế độ，开始录音
          if (_isVoiceCallActive) {
            _sendListenMessage();
          }
          break;

        case 'tts':
          // TTSTin nhắn处理
          final String state = jsonData['state'] ?? '';
          final String text = jsonData['text'] ?? '';

          if (state == 'stop' &&
              _suppressedTtsStopCompleter != null &&
              !_suppressedTtsStopCompleter!.isCompleted) {
            _suppressedTtsStopCompleter!.complete();
          }

          if (state == 'sentence_start' && text.isNotEmpty) {
            print('$TAG: 收到TTS句子: $text');
            if (_responseGateActive) {
              _gatedTtsSentences.add(text);
            } else {
              _dispatchEvent(
                XiaozhiServiceEvent(XiaozhiServiceEventType.textMessage, text),
              );
            }
          }
          break;

        case 'stt':
          // 处理Giọng nói识别结果
          final String text = jsonData['text'] ?? '';
          if (text.isNotEmpty) {
            print('$TAG: 收到Giọng nói识别结果: $text');
            // 先分发用户Tin nhắn事件
            _dispatchEvent(
              XiaozhiServiceEvent(XiaozhiServiceEventType.userMessage, text),
            );
          }
          break;

        case 'mcp':
          unawaited(_handleMcpEnvelope(jsonData));
          break;

        case 'emotion':
          // 处理表情Tin nhắn
          final String emotion = jsonData['emotion'] ?? '';
          if (emotion.isNotEmpty) {
            print('$TAG: 收到表情Tin nhắn: $emotion');
            _dispatchEvent(
              XiaozhiServiceEvent(
                XiaozhiServiceEventType.textMessage,
                '表情: $emotion',
              ),
            );
          }
          break;

        default:
          // 对于其他类型的Tin nhắn，直接忽略
          print('$TAG: 收到未知类型Tin nhắn: $type, 原始数据: $message');
      }
    } catch (e) {
      print('$TAG: 解析Tin nhắnThất bại: $e, 原始Tin nhắn: $message');
    }
  }

  Future<void> _handleMcpEnvelope(Map<String, dynamic> envelope) async {
    final payload = envelope['payload'];
    if (payload is! Map) return;
    final request = Map<String, dynamic>.from(payload);
    final method = (request['method'] ?? '').toString();
    final id = request['id'];
    if (method.isEmpty) return;

    _mcpBackendDetected = true;

    if (method == 'initialize') {
      _sendMcpResult(id, {
        'protocolVersion': '2024-11-05',
        'capabilities': {'tools': <String, dynamic>{}},
        'serverInfo': {
          'name': 'AI-LHHT-Android',
          'version': '4.1.1',
        },
      });
      return;
    }

    if (method == 'tools/list') {
      _sendMcpResult(id, {
        'tools': [
          {
            'name': 'self.realtime.lookup',
            'description': 'Tra cứu dữ liệu realtime và tiện ích Việt Nam trong ứng dụng AI-LHHT. '
                'Hãy dùng tool này khi người dùng hỏi xổ số, thời tiết, AQI, tỷ giá, đổi tiền, '
                'crypto, tin tức, mã vùng, nhà mạng, biển số, lịch âm, thể thao, giá vàng hoặc '
                'các truy vấn realtime khác, hoặc thông tin Device-ID/Client-ID/MAC của thiết bị hiện tại. '
                'Truyền nguyên câu hỏi của người dùng vào query.',
            'inputSchema': {
              'type': 'object',
              'properties': {
                'query': {
                  'type': 'string',
                  'description': 'Nguyên câu hỏi cần tra cứu.',
                },
              },
              'required': ['query'],
            },
          },
        ],
      });
      return;
    }

    if (method == 'tools/call') {
      final params = request['params'];
      if (params is! Map) {
        _sendMcpError(id, -32602, 'Missing params');
        return;
      }
      final name = (params['name'] ?? '').toString();
      if (name != 'self.realtime.lookup') {
        _sendMcpError(id, -32601, 'Unknown tool: $name');
        return;
      }
      final arguments = params['arguments'];
      final query = arguments is Map ? (arguments['query'] ?? '').toString().trim() : '';
      if (query.isEmpty) {
        _sendMcpError(id, -32602, 'query is required');
        return;
      }
      try {
        final handler = _realtimeMcpHandler;
        if (handler == null) {
          throw StateError('Realtime tool handler is not registered.');
        }
        final resultText = (await handler(query)).trim();
        _sendMcpResult(id, {
          'content': [
            {'type': 'text', 'text': resultText.isEmpty ? 'Không có dữ liệu.' : resultText},
          ],
          'isError': false,
        });
      } catch (e) {
        _sendMcpResult(id, {
          'content': [
            {'type': 'text', 'text': 'Không tra cứu được dữ liệu lúc này: $e'},
          ],
          'isError': true,
        });
      }
      return;
    }

    if (id != null) {
      _sendMcpError(id, -32601, 'Method not implemented: $method');
    }
  }

  void _sendMcpResult(dynamic id, Map<String, dynamic> result) {
    if (id == null) return;
    _sendMcpPayload({
      'jsonrpc': '2.0',
      'id': id,
      'result': result,
    });
  }

  void _sendMcpError(dynamic id, int code, String message) {
    if (id == null) return;
    _sendMcpPayload({
      'jsonrpc': '2.0',
      'id': id,
      'error': {'code': code, 'message': message},
    });
  }

  void _sendMcpPayload(Map<String, dynamic> payload) {
    final envelope = <String, dynamic>{
      if (_sessionId != null) 'session_id': _sessionId,
      'type': 'mcp',
      'payload': payload,
    };
    _webSocketManager?.sendMessage(jsonEncode(envelope));
  }

  /// 开始通话
  void _startCall() {
    try {
      // 发送开始通话Tin nhắn
      final startMessage = {
        'type': 'start',
        'mode': 'auto',
        'audio_params': {
          'format': 'opus',
          'sample_rate': 16000,
          'channels': 1,
          'frame_duration': 60,
        },
      };
      _webSocketManager?.sendMessage(jsonEncode(startMessage));
      print('$TAG: 已发送开始通话Tin nhắn');
    } catch (e) {
      print('$TAG: 开始通话Thất bại: $e');
    }
  }

  /// Chọn đường phát tiếng. Khi true, binary TTS của Xiaozhi bị tắt và UI
  /// dùng UnifiedSpeechOutputService cho cả Agent/Tool để giữ một giọng.
  void setSuppressIncomingAudio(bool value) {
    _suppressIncomingAudio = value;
    if (value) {
      unawaited(AudioUtil.stopPlaying());
    }
  }

  /// Khóa tạm phản hồi Agent cho tới khi STT được Tool Router phân loại.
  void beginResponseGate() {
    _responseGateTimer?.cancel();
    _responseGateActive = true;
    _gatedAudioFrames.clear();
    _gatedTtsSentences.clear();
    // Fail-open: nếu STT không về do mạng, không giữ phản hồi mãi mãi.
    _responseGateTimer = Timer(const Duration(seconds: 8), () {
      unawaited(releaseResponseGate());
    });
  }

  /// Hội thoại bình thường: mở gate và phát/dispatch phần đã buffer.
  Future<void> releaseResponseGate() async {
    if (!_responseGateActive) return;
    _responseGateTimer?.cancel();
    _responseGateTimer = null;
    _responseGateActive = false;

    final sentences = List<String>.from(_gatedTtsSentences);
    final audioFrames = List<Uint8List>.from(_gatedAudioFrames);
    _gatedTtsSentences.clear();
    _gatedAudioFrames.clear();

    for (final text in sentences) {
      if (text.trim().isNotEmpty) {
        _dispatchEvent(
          XiaozhiServiceEvent(XiaozhiServiceEventType.textMessage, text),
        );
      }
    }
    if (!_suppressIncomingAudio) {
      for (final frame in audioFrames) {
        await AudioUtil.playOpusData(frame);
      }
    }
  }

  /// Local tool/command đã nhận câu nói: bỏ mọi phản hồi Agent đã chạy đua
  /// phía cloud rồi mới abort session.
  void discardResponseGate() {
    _responseGateTimer?.cancel();
    _responseGateTimer = null;
    _responseGateActive = false;
    _gatedAudioFrames.clear();
    _gatedTtsSentences.clear();
  }

  /// 中断音频播放
  Future<void> stopPlayback() async {
    try {
      print('$TAG: 正在停止音频播放');

      // 简单直接地停止播放
      await AudioUtil.stopPlaying();

      print('$TAG: 音频播放已停止');
    } catch (e) {
      print('$TAG: 停止音频播放Thất bại: $e');
    }
  }

  /// 判断是否Đã kết nối
  bool get isConnected =>
      _isConnected &&
      _webSocketManager != null &&
      _webSocketManager!.isConnected;

  /// 判断是否静音
  bool get isMuted => _isMuted;

  /// 判断Giọng nói通话是否活跃
  bool get isVoiceCallActive => _isVoiceCallActive;

  /// 释放资源
  Future<void> dispose() async {
    await disconnect();
    await AudioUtil.dispose();
    _listeners.clear();
    print('$TAG: 资源已释放');
  }

  /// 开始监听（Nhấn giữ để nóiChế độ）
  Future<void> startListening({String mode = 'manual'}) async {
    if (!_isConnected || _webSocketManager == null) {
      await connect();
    }

    try {
      // 确保已经有Cuộc trò chuyệnID
      if (_sessionId == null) {
        print('$TAG: 没有Cuộc trò chuyệnID，无法开始监听');
        return;
      }

      // 开始录音
      await AudioUtil.startRecording();

      // 发送开始监听命令
      final message = {
        'session_id': _sessionId,
        'type': 'listen',
        'state': 'start',
        'mode': mode,
      };
      _webSocketManager?.sendMessage(jsonEncode(message));
      print('$TAG: 已发送开始监听Tin nhắn (Nhấn giữ để nói)');

      // Cài đặt音频流订阅
      _audioStreamSubscription = AudioUtil.audioStream.listen((opusData) {
        // 发送音频数据
        _webSocketManager?.sendBinaryMessage(opusData);
      });
    } catch (e) {
      print('$TAG: 开始监听Thất bại: $e');
      throw Exception('Không thể bắt đầu nhập giọng nói: $e');
    }
  }

  /// 停止监听（Nhấn giữ để nóiChế độ）
  Future<void> stopListening() async {
    try {
      // Hủy音频流订阅
      await _audioStreamSubscription?.cancel();
      _audioStreamSubscription = null;

      // 停止录音
      await AudioUtil.stopRecording();

      // 发送停止监听命令
      if (_sessionId != null && _webSocketManager != null) {
        final message = {
          'session_id': _sessionId,
          'type': 'listen',
          'state': 'stop',
        };
        _webSocketManager?.sendMessage(jsonEncode(message));
        print('$TAG: 已发送停止监听Tin nhắn');
      }
    } catch (e) {
      print('$TAG: 停止监听Thất bại: $e');
    }
  }


  /// Ngắt câu trả lời/TTS hiện tại mà không tự khởi động lại microphone.
  /// Dùng cho chế độ phiên dịch: Xiaozhi chỉ làm ASR, sau đó app tự tạo bản dịch.
  Future<void> interruptResponse() async {
    try {
      if (_webSocketManager != null && _isConnected && _sessionId != null) {
        final abortMessage = {
          'session_id': _sessionId,
          'type': 'abort',
          'reason': 'interpreter_takeover',
        };
        _webSocketManager?.sendMessage(jsonEncode(abortMessage));
      }
      await stopPlayback();
    } catch (e) {
      print('$TAG: Không thể ngắt phản hồi hiện tại: $e');
    }
  }

  /// 发送中断Tin nhắn
  Future<void> sendAbortMessage() async {
    try {
      if (_webSocketManager != null && _isConnected && _sessionId != null) {
        final abortMessage = {
          'session_id': _sessionId,
          'type': 'abort',
          'reason': 'wake_word_detected',
        };
        _webSocketManager?.sendMessage(jsonEncode(abortMessage));
        print('$TAG: 发送中断Tin nhắn: $abortMessage');

        // 如果当前正在录音，短暂停顿后继续
        if (_isSpeaking) {
          await stopListeningCall();
          await Future.delayed(const Duration(milliseconds: 500));
          await startListeningCall();
        }
      }
    } catch (e) {
      print('$TAG: 发送中断Tin nhắnThất bại: $e');
    }
  }

  /// 判断是否正在说话
  bool get _isSpeaking => _audioStreamSubscription != null;
}
